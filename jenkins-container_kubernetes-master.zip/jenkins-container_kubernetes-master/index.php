Home Page
<pre>
<?php
print `ifconfig`;
?>
</pre>